﻿namespace Kandoi_SiddhantKumar_BusinessApplicationAssignment4
{
    partial class InvestMeForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InvestMeForm1));
            this.DisplayButton1 = new System.Windows.Forms.Button();
            this.ProceedButton1 = new System.Windows.Forms.Button();
            this.ClearButton1 = new System.Windows.Forms.Button();
            this.ExitButton1 = new System.Windows.Forms.Button();
            this.SummaryButton1 = new System.Windows.Forms.Button();
            this.InvestmentAmountLabel1 = new System.Windows.Forms.Label();
            this.InvestmentAmountTextBox1 = new System.Windows.Forms.TextBox();
            this.InvestMeLabel1 = new System.Windows.Forms.Label();
            this.PlanGroupBox1 = new System.Windows.Forms.GroupBox();
            this.TenYearsPlanRadioButton1 = new System.Windows.Forms.RadioButton();
            this.FiveYearsPlanRadioButton1 = new System.Windows.Forms.RadioButton();
            this.ThreeYearsPlanRadioButton1 = new System.Windows.Forms.RadioButton();
            this.OneYearPlanRadioButton1 = new System.Windows.Forms.RadioButton();
            this.ConfirmButton1 = new System.Windows.Forms.Button();
            this.EnterClientDetailsGroupBox1 = new System.Windows.Forms.GroupBox();
            this.EmailIDAnsTextBox1 = new System.Windows.Forms.TextBox();
            this.TelephoneAnsTextBox1 = new System.Windows.Forms.TextBox();
            this.ClientNameAnsTextBox1 = new System.Windows.Forms.TextBox();
            this.TelephoneLabel1 = new System.Windows.Forms.Label();
            this.EmailIDLabel1 = new System.Windows.Forms.Label();
            this.ClientNameLabel1 = new System.Windows.Forms.Label();
            this.TransactionNumberAnswerClientDetailsLabel1 = new System.Windows.Forms.Label();
            this.TransactionNumberClientDetailsLabel1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SummaryGroupBox1 = new System.Windows.Forms.GroupBox();
            this.SummaryListTranNumLabel1 = new System.Windows.Forms.Label();
            this.AverageDurationAnsLabel1 = new System.Windows.Forms.Label();
            this.AverageDurationLabel1 = new System.Windows.Forms.Label();
            this.TotalInterestAnsLabel1 = new System.Windows.Forms.Label();
            this.TotalInterestLabel1 = new System.Windows.Forms.Label();
            this.TotalAmountInvestedAnsLabel1 = new System.Windows.Forms.Label();
            this.TotalAmountInvestedLabel1 = new System.Windows.Forms.Label();
            this.SummaryTransactionNumberListBox1 = new System.Windows.Forms.ListBox();
            this.SearchButton1 = new System.Windows.Forms.Button();
            this.SearchTextBox1 = new System.Windows.Forms.TextBox();
            this.SearchGroupBox1 = new System.Windows.Forms.GroupBox();
            this.SearchResultTermPlanAnswerLabel1 = new System.Windows.Forms.Label();
            this.SearchResultTermPlanLabel1 = new System.Windows.Forms.Label();
            this.SearchResultBalanceAmountAnswerLabel1 = new System.Windows.Forms.Label();
            this.SearchResultBalanceAmountLabel1 = new System.Windows.Forms.Label();
            this.SearchResultInvestedAmountAnswerLabel1 = new System.Windows.Forms.Label();
            this.SearchResultInvestedAmountLabel1 = new System.Windows.Forms.Label();
            this.SearchResultClientNameAnswerLabel1 = new System.Windows.Forms.Label();
            this.SearchResultNameLabel1 = new System.Windows.Forms.Label();
            this.SearchResultTelephoneAnswerLabel1 = new System.Windows.Forms.Label();
            this.SearchResultTelephoneabel1 = new System.Windows.Forms.Label();
            this.SearchResultEmailIdAnsLabel1 = new System.Windows.Forms.Label();
            this.SearchResultLabel1 = new System.Windows.Forms.Label();
            this.SearchEmailIdRadioButton1 = new System.Windows.Forms.RadioButton();
            this.SearchTransNumRadioButton1 = new System.Windows.Forms.RadioButton();
            this.SearchTransactionsListBox1 = new System.Windows.Forms.ListBox();
            this.InvestmentAmountGroupBox1 = new System.Windows.Forms.GroupBox();
            this.SearchListTransNumsLabel1 = new System.Windows.Forms.Label();
            this.InvestMeToolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.PlanGroupBox1.SuspendLayout();
            this.EnterClientDetailsGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SummaryGroupBox1.SuspendLayout();
            this.SearchGroupBox1.SuspendLayout();
            this.InvestmentAmountGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DisplayButton1
            // 
            this.DisplayButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayButton1.Location = new System.Drawing.Point(870, 29);
            this.DisplayButton1.Name = "DisplayButton1";
            this.DisplayButton1.Size = new System.Drawing.Size(93, 46);
            this.DisplayButton1.TabIndex = 2;
            this.DisplayButton1.Text = "&Display";
            this.DisplayButton1.UseVisualStyleBackColor = true;
            this.DisplayButton1.Click += new System.EventHandler(this.DisplayButton1_Click);
            // 
            // ProceedButton1
            // 
            this.ProceedButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProceedButton1.Location = new System.Drawing.Point(516, 239);
            this.ProceedButton1.Name = "ProceedButton1";
            this.ProceedButton1.Size = new System.Drawing.Size(93, 46);
            this.ProceedButton1.TabIndex = 3;
            this.ProceedButton1.Text = "&Proceed";
            this.ProceedButton1.UseVisualStyleBackColor = true;
            this.ProceedButton1.Click += new System.EventHandler(this.ProceedButton1_Click);
            // 
            // ClearButton1
            // 
            this.ClearButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton1.Location = new System.Drawing.Point(1441, 250);
            this.ClearButton1.Name = "ClearButton1";
            this.ClearButton1.Size = new System.Drawing.Size(93, 46);
            this.ClearButton1.TabIndex = 17;
            this.ClearButton1.Text = "C&lear";
            this.InvestMeToolTip1.SetToolTip(this.ClearButton1, "Click to Clear");
            this.ClearButton1.UseVisualStyleBackColor = true;
            this.ClearButton1.Click += new System.EventHandler(this.ClearButton1_Click);
            // 
            // ExitButton1
            // 
            this.ExitButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton1.Location = new System.Drawing.Point(1589, 250);
            this.ExitButton1.Name = "ExitButton1";
            this.ExitButton1.Size = new System.Drawing.Size(93, 46);
            this.ExitButton1.TabIndex = 18;
            this.ExitButton1.Text = "&Exit";
            this.InvestMeToolTip1.SetToolTip(this.ExitButton1, "Click to Exit");
            this.ExitButton1.UseVisualStyleBackColor = true;
            this.ExitButton1.Click += new System.EventHandler(this.ExitButton1_Click);
            // 
            // SummaryButton1
            // 
            this.SummaryButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryButton1.Location = new System.Drawing.Point(271, 217);
            this.SummaryButton1.Name = "SummaryButton1";
            this.SummaryButton1.Size = new System.Drawing.Size(111, 46);
            this.SummaryButton1.TabIndex = 12;
            this.SummaryButton1.Text = "S&ummary";
            this.SummaryButton1.UseVisualStyleBackColor = true;
            this.SummaryButton1.Click += new System.EventHandler(this.SummaryButton1_Click);
            // 
            // InvestmentAmountLabel1
            // 
            this.InvestmentAmountLabel1.AutoSize = true;
            this.InvestmentAmountLabel1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestmentAmountLabel1.Location = new System.Drawing.Point(14, 39);
            this.InvestmentAmountLabel1.Name = "InvestmentAmountLabel1";
            this.InvestmentAmountLabel1.Size = new System.Drawing.Size(514, 26);
            this.InvestmentAmountLabel1.TabIndex = 6;
            this.InvestmentAmountLabel1.Text = "Enter the amount client would like to invest in Euros";
            // 
            // InvestmentAmountTextBox1
            // 
            this.InvestmentAmountTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestmentAmountTextBox1.Location = new System.Drawing.Point(558, 39);
            this.InvestmentAmountTextBox1.Name = "InvestmentAmountTextBox1";
            this.InvestmentAmountTextBox1.Size = new System.Drawing.Size(290, 22);
            this.InvestmentAmountTextBox1.TabIndex = 1;
            this.InvestmentAmountTextBox1.Text = "Enter the amount here in Euro";
            this.InvestmentAmountTextBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.InvestmentAmountTextBox1_MouseClick);
            // 
            // InvestMeLabel1
            // 
            this.InvestMeLabel1.AutoSize = true;
            this.InvestMeLabel1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestMeLabel1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.InvestMeLabel1.Location = new System.Drawing.Point(318, 213);
            this.InvestMeLabel1.Name = "InvestMeLabel1";
            this.InvestMeLabel1.Size = new System.Drawing.Size(265, 19);
            this.InvestMeLabel1.TabIndex = 8;
            this.InvestMeLabel1.Text = "Medium term investment product";
            // 
            // PlanGroupBox1
            // 
            this.PlanGroupBox1.Controls.Add(this.TenYearsPlanRadioButton1);
            this.PlanGroupBox1.Controls.Add(this.FiveYearsPlanRadioButton1);
            this.PlanGroupBox1.Controls.Add(this.ThreeYearsPlanRadioButton1);
            this.PlanGroupBox1.Controls.Add(this.OneYearPlanRadioButton1);
            this.PlanGroupBox1.Controls.Add(this.ProceedButton1);
            this.PlanGroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlanGroupBox1.Location = new System.Drawing.Point(224, 376);
            this.PlanGroupBox1.Name = "PlanGroupBox1";
            this.PlanGroupBox1.Size = new System.Drawing.Size(730, 301);
            this.PlanGroupBox1.TabIndex = 2;
            this.PlanGroupBox1.TabStop = false;
            this.PlanGroupBox1.Text = "Choose the Plan";
            this.InvestMeToolTip1.SetToolTip(this.PlanGroupBox1, "Choose the Plan for client");
            // 
            // TenYearsPlanRadioButton1
            // 
            this.TenYearsPlanRadioButton1.AutoSize = true;
            this.TenYearsPlanRadioButton1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TenYearsPlanRadioButton1.Location = new System.Drawing.Point(25, 217);
            this.TenYearsPlanRadioButton1.Name = "TenYearsPlanRadioButton1";
            this.TenYearsPlanRadioButton1.Size = new System.Drawing.Size(140, 23);
            this.TenYearsPlanRadioButton1.TabIndex = 6;
            this.TenYearsPlanRadioButton1.TabStop = true;
            this.TenYearsPlanRadioButton1.Text = "Ten Years Plan";
            this.TenYearsPlanRadioButton1.UseVisualStyleBackColor = true;
            // 
            // FiveYearsPlanRadioButton1
            // 
            this.FiveYearsPlanRadioButton1.AutoSize = true;
            this.FiveYearsPlanRadioButton1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FiveYearsPlanRadioButton1.Location = new System.Drawing.Point(25, 158);
            this.FiveYearsPlanRadioButton1.Name = "FiveYearsPlanRadioButton1";
            this.FiveYearsPlanRadioButton1.Size = new System.Drawing.Size(142, 23);
            this.FiveYearsPlanRadioButton1.TabIndex = 5;
            this.FiveYearsPlanRadioButton1.TabStop = true;
            this.FiveYearsPlanRadioButton1.Text = "Five Years Plan";
            this.FiveYearsPlanRadioButton1.UseVisualStyleBackColor = true;
            // 
            // ThreeYearsPlanRadioButton1
            // 
            this.ThreeYearsPlanRadioButton1.AutoSize = true;
            this.ThreeYearsPlanRadioButton1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThreeYearsPlanRadioButton1.Location = new System.Drawing.Point(25, 98);
            this.ThreeYearsPlanRadioButton1.Name = "ThreeYearsPlanRadioButton1";
            this.ThreeYearsPlanRadioButton1.Size = new System.Drawing.Size(121, 23);
            this.ThreeYearsPlanRadioButton1.TabIndex = 4;
            this.ThreeYearsPlanRadioButton1.TabStop = true;
            this.ThreeYearsPlanRadioButton1.Text = "3 Years Plan";
            this.ThreeYearsPlanRadioButton1.UseVisualStyleBackColor = true;
            // 
            // OneYearPlanRadioButton1
            // 
            this.OneYearPlanRadioButton1.AutoSize = true;
            this.OneYearPlanRadioButton1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OneYearPlanRadioButton1.Location = new System.Drawing.Point(25, 43);
            this.OneYearPlanRadioButton1.Name = "OneYearPlanRadioButton1";
            this.OneYearPlanRadioButton1.Size = new System.Drawing.Size(114, 23);
            this.OneYearPlanRadioButton1.TabIndex = 7;
            this.OneYearPlanRadioButton1.TabStop = true;
            this.OneYearPlanRadioButton1.Text = "1 Year Plan";
            this.OneYearPlanRadioButton1.UseVisualStyleBackColor = true;
            // 
            // ConfirmButton1
            // 
            this.ConfirmButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmButton1.Location = new System.Drawing.Point(542, 244);
            this.ConfirmButton1.Name = "ConfirmButton1";
            this.ConfirmButton1.Size = new System.Drawing.Size(93, 46);
            this.ConfirmButton1.TabIndex = 11;
            this.ConfirmButton1.Text = "&Confirm";
            this.ConfirmButton1.UseVisualStyleBackColor = true;
            this.ConfirmButton1.Click += new System.EventHandler(this.ConfirmButton1_Click);
            // 
            // EnterClientDetailsGroupBox1
            // 
            this.EnterClientDetailsGroupBox1.Controls.Add(this.EmailIDAnsTextBox1);
            this.EnterClientDetailsGroupBox1.Controls.Add(this.TelephoneAnsTextBox1);
            this.EnterClientDetailsGroupBox1.Controls.Add(this.ClientNameAnsTextBox1);
            this.EnterClientDetailsGroupBox1.Controls.Add(this.ConfirmButton1);
            this.EnterClientDetailsGroupBox1.Controls.Add(this.TelephoneLabel1);
            this.EnterClientDetailsGroupBox1.Controls.Add(this.EmailIDLabel1);
            this.EnterClientDetailsGroupBox1.Controls.Add(this.ClientNameLabel1);
            this.EnterClientDetailsGroupBox1.Controls.Add(this.TransactionNumberAnswerClientDetailsLabel1);
            this.EnterClientDetailsGroupBox1.Controls.Add(this.TransactionNumberClientDetailsLabel1);
            this.EnterClientDetailsGroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterClientDetailsGroupBox1.Location = new System.Drawing.Point(993, 376);
            this.EnterClientDetailsGroupBox1.Name = "EnterClientDetailsGroupBox1";
            this.EnterClientDetailsGroupBox1.Size = new System.Drawing.Size(689, 301);
            this.EnterClientDetailsGroupBox1.TabIndex = 6;
            this.EnterClientDetailsGroupBox1.TabStop = false;
            this.EnterClientDetailsGroupBox1.Text = "Enter Client Details Please";
            this.InvestMeToolTip1.SetToolTip(this.EnterClientDetailsGroupBox1, "Client Details Please!");
            // 
            // EmailIDAnsTextBox1
            // 
            this.EmailIDAnsTextBox1.Location = new System.Drawing.Point(381, 239);
            this.EmailIDAnsTextBox1.Name = "EmailIDAnsTextBox1";
            this.EmailIDAnsTextBox1.Size = new System.Drawing.Size(100, 24);
            this.EmailIDAnsTextBox1.TabIndex = 10;
            // 
            // TelephoneAnsTextBox1
            // 
            this.TelephoneAnsTextBox1.Location = new System.Drawing.Point(381, 188);
            this.TelephoneAnsTextBox1.Name = "TelephoneAnsTextBox1";
            this.TelephoneAnsTextBox1.Size = new System.Drawing.Size(100, 24);
            this.TelephoneAnsTextBox1.TabIndex = 9;
            // 
            // ClientNameAnsTextBox1
            // 
            this.ClientNameAnsTextBox1.Location = new System.Drawing.Point(381, 137);
            this.ClientNameAnsTextBox1.Name = "ClientNameAnsTextBox1";
            this.ClientNameAnsTextBox1.Size = new System.Drawing.Size(100, 24);
            this.ClientNameAnsTextBox1.TabIndex = 8;
            // 
            // TelephoneLabel1
            // 
            this.TelephoneLabel1.AutoSize = true;
            this.TelephoneLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TelephoneLabel1.Location = new System.Drawing.Point(41, 193);
            this.TelephoneLabel1.Name = "TelephoneLabel1";
            this.TelephoneLabel1.Size = new System.Drawing.Size(134, 18);
            this.TelephoneLabel1.TabIndex = 4;
            this.TelephoneLabel1.Text = "Telephone Number";
            // 
            // EmailIDLabel1
            // 
            this.EmailIDLabel1.AutoSize = true;
            this.EmailIDLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailIDLabel1.Location = new System.Drawing.Point(41, 244);
            this.EmailIDLabel1.Name = "EmailIDLabel1";
            this.EmailIDLabel1.Size = new System.Drawing.Size(63, 18);
            this.EmailIDLabel1.TabIndex = 3;
            this.EmailIDLabel1.Text = "Email ID";
            // 
            // ClientNameLabel1
            // 
            this.ClientNameLabel1.AutoSize = true;
            this.ClientNameLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClientNameLabel1.Location = new System.Drawing.Point(38, 143);
            this.ClientNameLabel1.Name = "ClientNameLabel1";
            this.ClientNameLabel1.Size = new System.Drawing.Size(89, 18);
            this.ClientNameLabel1.TabIndex = 2;
            this.ClientNameLabel1.Text = "Client Name";
            // 
            // TransactionNumberAnswerClientDetailsLabel1
            // 
            this.TransactionNumberAnswerClientDetailsLabel1.AutoEllipsis = true;
            this.TransactionNumberAnswerClientDetailsLabel1.BackColor = System.Drawing.Color.White;
            this.TransactionNumberAnswerClientDetailsLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TransactionNumberAnswerClientDetailsLabel1.Location = new System.Drawing.Point(378, 83);
            this.TransactionNumberAnswerClientDetailsLabel1.Name = "TransactionNumberAnswerClientDetailsLabel1";
            this.TransactionNumberAnswerClientDetailsLabel1.Size = new System.Drawing.Size(103, 18);
            this.TransactionNumberAnswerClientDetailsLabel1.TabIndex = 1;
            // 
            // TransactionNumberClientDetailsLabel1
            // 
            this.TransactionNumberClientDetailsLabel1.AutoSize = true;
            this.TransactionNumberClientDetailsLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionNumberClientDetailsLabel1.Location = new System.Drawing.Point(38, 84);
            this.TransactionNumberClientDetailsLabel1.Name = "TransactionNumberClientDetailsLabel1";
            this.TransactionNumberClientDetailsLabel1.Size = new System.Drawing.Size(143, 18);
            this.TransactionNumberClientDetailsLabel1.TabIndex = 0;
            this.TransactionNumberClientDetailsLabel1.Text = "Transaction Number";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Kandoi_SiddhantKumar_BusinessApplicationAssignment4.Properties.Resources.InvestMe;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 220);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // SummaryGroupBox1
            // 
            this.SummaryGroupBox1.Controls.Add(this.SummaryListTranNumLabel1);
            this.SummaryGroupBox1.Controls.Add(this.AverageDurationAnsLabel1);
            this.SummaryGroupBox1.Controls.Add(this.AverageDurationLabel1);
            this.SummaryGroupBox1.Controls.Add(this.TotalInterestAnsLabel1);
            this.SummaryGroupBox1.Controls.Add(this.TotalInterestLabel1);
            this.SummaryGroupBox1.Controls.Add(this.TotalAmountInvestedAnsLabel1);
            this.SummaryGroupBox1.Controls.Add(this.TotalAmountInvestedLabel1);
            this.SummaryGroupBox1.Controls.Add(this.SummaryButton1);
            this.SummaryGroupBox1.Controls.Add(this.SummaryTransactionNumberListBox1);
            this.SummaryGroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryGroupBox1.Location = new System.Drawing.Point(1264, 707);
            this.SummaryGroupBox1.Name = "SummaryGroupBox1";
            this.SummaryGroupBox1.Size = new System.Drawing.Size(555, 276);
            this.SummaryGroupBox1.TabIndex = 7;
            this.SummaryGroupBox1.TabStop = false;
            this.SummaryGroupBox1.Text = "Summary Report";
            this.InvestMeToolTip1.SetToolTip(this.SummaryGroupBox1, "Get Summary");
            // 
            // SummaryListTranNumLabel1
            // 
            this.SummaryListTranNumLabel1.AutoSize = true;
            this.SummaryListTranNumLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryListTranNumLabel1.Location = new System.Drawing.Point(14, 26);
            this.SummaryListTranNumLabel1.Name = "SummaryListTranNumLabel1";
            this.SummaryListTranNumLabel1.Size = new System.Drawing.Size(151, 18);
            this.SummaryListTranNumLabel1.TabIndex = 7;
            this.SummaryListTranNumLabel1.Text = "Transaction Numbers";
            // 
            // AverageDurationAnsLabel1
            // 
            this.AverageDurationAnsLabel1.AutoEllipsis = true;
            this.AverageDurationAnsLabel1.BackColor = System.Drawing.Color.White;
            this.AverageDurationAnsLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AverageDurationAnsLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageDurationAnsLabel1.Location = new System.Drawing.Point(404, 169);
            this.AverageDurationAnsLabel1.Name = "AverageDurationAnsLabel1";
            this.AverageDurationAnsLabel1.Size = new System.Drawing.Size(126, 27);
            this.AverageDurationAnsLabel1.TabIndex = 6;
            // 
            // AverageDurationLabel1
            // 
            this.AverageDurationLabel1.AutoSize = true;
            this.AverageDurationLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageDurationLabel1.Location = new System.Drawing.Point(218, 178);
            this.AverageDurationLabel1.Name = "AverageDurationLabel1";
            this.AverageDurationLabel1.Size = new System.Drawing.Size(121, 18);
            this.AverageDurationLabel1.TabIndex = 5;
            this.AverageDurationLabel1.Text = "Average Duration";
            // 
            // TotalInterestAnsLabel1
            // 
            this.TotalInterestAnsLabel1.AutoEllipsis = true;
            this.TotalInterestAnsLabel1.BackColor = System.Drawing.Color.White;
            this.TotalInterestAnsLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalInterestAnsLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalInterestAnsLabel1.Location = new System.Drawing.Point(404, 110);
            this.TotalInterestAnsLabel1.Name = "TotalInterestAnsLabel1";
            this.TotalInterestAnsLabel1.Size = new System.Drawing.Size(126, 27);
            this.TotalInterestAnsLabel1.TabIndex = 4;
            // 
            // TotalInterestLabel1
            // 
            this.TotalInterestLabel1.AutoSize = true;
            this.TotalInterestLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalInterestLabel1.Location = new System.Drawing.Point(220, 119);
            this.TotalInterestLabel1.Name = "TotalInterestLabel1";
            this.TotalInterestLabel1.Size = new System.Drawing.Size(93, 18);
            this.TotalInterestLabel1.TabIndex = 3;
            this.TotalInterestLabel1.Text = "Total Interest";
            // 
            // TotalAmountInvestedAnsLabel1
            // 
            this.TotalAmountInvestedAnsLabel1.AutoEllipsis = true;
            this.TotalAmountInvestedAnsLabel1.BackColor = System.Drawing.Color.White;
            this.TotalAmountInvestedAnsLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalAmountInvestedAnsLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmountInvestedAnsLabel1.Location = new System.Drawing.Point(404, 47);
            this.TotalAmountInvestedAnsLabel1.Name = "TotalAmountInvestedAnsLabel1";
            this.TotalAmountInvestedAnsLabel1.Size = new System.Drawing.Size(126, 28);
            this.TotalAmountInvestedAnsLabel1.TabIndex = 2;
            // 
            // TotalAmountInvestedLabel1
            // 
            this.TotalAmountInvestedLabel1.AutoSize = true;
            this.TotalAmountInvestedLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmountInvestedLabel1.Location = new System.Drawing.Point(218, 57);
            this.TotalAmountInvestedLabel1.Name = "TotalAmountInvestedLabel1";
            this.TotalAmountInvestedLabel1.Size = new System.Drawing.Size(154, 18);
            this.TotalAmountInvestedLabel1.TabIndex = 1;
            this.TotalAmountInvestedLabel1.Text = "Total Amount Invested";
            // 
            // SummaryTransactionNumberListBox1
            // 
            this.SummaryTransactionNumberListBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SummaryTransactionNumberListBox1.FormattingEnabled = true;
            this.SummaryTransactionNumberListBox1.ItemHeight = 18;
            this.SummaryTransactionNumberListBox1.Location = new System.Drawing.Point(17, 59);
            this.SummaryTransactionNumberListBox1.Name = "SummaryTransactionNumberListBox1";
            this.SummaryTransactionNumberListBox1.Size = new System.Drawing.Size(195, 184);
            this.SummaryTransactionNumberListBox1.TabIndex = 32;
            // 
            // SearchButton1
            // 
            this.SearchButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton1.Location = new System.Drawing.Point(455, 50);
            this.SearchButton1.Name = "SearchButton1";
            this.SearchButton1.Size = new System.Drawing.Size(93, 46);
            this.SearchButton1.TabIndex = 15;
            this.SearchButton1.Text = "&Search";
            this.SearchButton1.UseVisualStyleBackColor = true;
            this.SearchButton1.Click += new System.EventHandler(this.SearchButton1_Click);
            // 
            // SearchTextBox1
            // 
            this.SearchTextBox1.Location = new System.Drawing.Point(92, 72);
            this.SearchTextBox1.Name = "SearchTextBox1";
            this.SearchTextBox1.Size = new System.Drawing.Size(327, 24);
            this.SearchTextBox1.TabIndex = 14;
            this.InvestMeToolTip1.SetToolTip(this.SearchTextBox1, "Enter search string here");
            // 
            // SearchGroupBox1
            // 
            this.SearchGroupBox1.Controls.Add(this.SearchListTransNumsLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultTermPlanAnswerLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultTermPlanLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultBalanceAmountAnswerLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultBalanceAmountLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultInvestedAmountAnswerLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultInvestedAmountLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultClientNameAnswerLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultNameLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultTelephoneAnswerLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultTelephoneabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultEmailIdAnsLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchResultLabel1);
            this.SearchGroupBox1.Controls.Add(this.SearchEmailIdRadioButton1);
            this.SearchGroupBox1.Controls.Add(this.SearchTransNumRadioButton1);
            this.SearchGroupBox1.Controls.Add(this.SearchTransactionsListBox1);
            this.SearchGroupBox1.Controls.Add(this.SearchTextBox1);
            this.SearchGroupBox1.Controls.Add(this.SearchButton1);
            this.SearchGroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchGroupBox1.Location = new System.Drawing.Point(96, 707);
            this.SearchGroupBox1.Name = "SearchGroupBox1";
            this.SearchGroupBox1.Size = new System.Drawing.Size(1113, 276);
            this.SearchGroupBox1.TabIndex = 16;
            this.SearchGroupBox1.TabStop = false;
            this.SearchGroupBox1.Text = "Search Records";
            this.InvestMeToolTip1.SetToolTip(this.SearchGroupBox1, "Search Here");
            // 
            // SearchResultTermPlanAnswerLabel1
            // 
            this.SearchResultTermPlanAnswerLabel1.AutoEllipsis = true;
            this.SearchResultTermPlanAnswerLabel1.BackColor = System.Drawing.Color.White;
            this.SearchResultTermPlanAnswerLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchResultTermPlanAnswerLabel1.Location = new System.Drawing.Point(979, 220);
            this.SearchResultTermPlanAnswerLabel1.Name = "SearchResultTermPlanAnswerLabel1";
            this.SearchResultTermPlanAnswerLabel1.Size = new System.Drawing.Size(117, 23);
            this.SearchResultTermPlanAnswerLabel1.TabIndex = 30;
            // 
            // SearchResultTermPlanLabel1
            // 
            this.SearchResultTermPlanLabel1.AutoSize = true;
            this.SearchResultTermPlanLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchResultTermPlanLabel1.Location = new System.Drawing.Point(800, 221);
            this.SearchResultTermPlanLabel1.Name = "SearchResultTermPlanLabel1";
            this.SearchResultTermPlanLabel1.Size = new System.Drawing.Size(76, 18);
            this.SearchResultTermPlanLabel1.TabIndex = 29;
            this.SearchResultTermPlanLabel1.Text = "Term Plan";
            // 
            // SearchResultBalanceAmountAnswerLabel1
            // 
            this.SearchResultBalanceAmountAnswerLabel1.AutoEllipsis = true;
            this.SearchResultBalanceAmountAnswerLabel1.BackColor = System.Drawing.Color.White;
            this.SearchResultBalanceAmountAnswerLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchResultBalanceAmountAnswerLabel1.Location = new System.Drawing.Point(979, 168);
            this.SearchResultBalanceAmountAnswerLabel1.Name = "SearchResultBalanceAmountAnswerLabel1";
            this.SearchResultBalanceAmountAnswerLabel1.Size = new System.Drawing.Size(117, 28);
            this.SearchResultBalanceAmountAnswerLabel1.TabIndex = 28;
            // 
            // SearchResultBalanceAmountLabel1
            // 
            this.SearchResultBalanceAmountLabel1.AutoSize = true;
            this.SearchResultBalanceAmountLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchResultBalanceAmountLabel1.Location = new System.Drawing.Point(800, 170);
            this.SearchResultBalanceAmountLabel1.Name = "SearchResultBalanceAmountLabel1";
            this.SearchResultBalanceAmountLabel1.Size = new System.Drawing.Size(153, 18);
            this.SearchResultBalanceAmountLabel1.TabIndex = 27;
            this.SearchResultBalanceAmountLabel1.Text = "Balance Amount Total";
            // 
            // SearchResultInvestedAmountAnswerLabel1
            // 
            this.SearchResultInvestedAmountAnswerLabel1.AutoEllipsis = true;
            this.SearchResultInvestedAmountAnswerLabel1.BackColor = System.Drawing.Color.White;
            this.SearchResultInvestedAmountAnswerLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchResultInvestedAmountAnswerLabel1.Location = new System.Drawing.Point(979, 118);
            this.SearchResultInvestedAmountAnswerLabel1.Name = "SearchResultInvestedAmountAnswerLabel1";
            this.SearchResultInvestedAmountAnswerLabel1.Size = new System.Drawing.Size(117, 28);
            this.SearchResultInvestedAmountAnswerLabel1.TabIndex = 26;
            // 
            // SearchResultInvestedAmountLabel1
            // 
            this.SearchResultInvestedAmountLabel1.AutoSize = true;
            this.SearchResultInvestedAmountLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchResultInvestedAmountLabel1.Location = new System.Drawing.Point(800, 121);
            this.SearchResultInvestedAmountLabel1.Name = "SearchResultInvestedAmountLabel1";
            this.SearchResultInvestedAmountLabel1.Size = new System.Drawing.Size(117, 18);
            this.SearchResultInvestedAmountLabel1.TabIndex = 25;
            this.SearchResultInvestedAmountLabel1.Text = "Invested Amount";
            // 
            // SearchResultClientNameAnswerLabel1
            // 
            this.SearchResultClientNameAnswerLabel1.AutoEllipsis = true;
            this.SearchResultClientNameAnswerLabel1.BackColor = System.Drawing.Color.White;
            this.SearchResultClientNameAnswerLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchResultClientNameAnswerLabel1.Location = new System.Drawing.Point(207, 169);
            this.SearchResultClientNameAnswerLabel1.Name = "SearchResultClientNameAnswerLabel1";
            this.SearchResultClientNameAnswerLabel1.Size = new System.Drawing.Size(219, 27);
            this.SearchResultClientNameAnswerLabel1.TabIndex = 24;
            // 
            // SearchResultNameLabel1
            // 
            this.SearchResultNameLabel1.AutoSize = true;
            this.SearchResultNameLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchResultNameLabel1.Location = new System.Drawing.Point(89, 170);
            this.SearchResultNameLabel1.Name = "SearchResultNameLabel1";
            this.SearchResultNameLabel1.Size = new System.Drawing.Size(48, 18);
            this.SearchResultNameLabel1.TabIndex = 23;
            this.SearchResultNameLabel1.Text = "Name";
            // 
            // SearchResultTelephoneAnswerLabel1
            // 
            this.SearchResultTelephoneAnswerLabel1.AutoEllipsis = true;
            this.SearchResultTelephoneAnswerLabel1.BackColor = System.Drawing.Color.White;
            this.SearchResultTelephoneAnswerLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchResultTelephoneAnswerLabel1.Location = new System.Drawing.Point(207, 225);
            this.SearchResultTelephoneAnswerLabel1.Name = "SearchResultTelephoneAnswerLabel1";
            this.SearchResultTelephoneAnswerLabel1.Size = new System.Drawing.Size(93, 24);
            this.SearchResultTelephoneAnswerLabel1.TabIndex = 22;
            // 
            // SearchResultTelephoneabel1
            // 
            this.SearchResultTelephoneabel1.AutoSize = true;
            this.SearchResultTelephoneabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchResultTelephoneabel1.Location = new System.Drawing.Point(89, 225);
            this.SearchResultTelephoneabel1.Name = "SearchResultTelephoneabel1";
            this.SearchResultTelephoneabel1.Size = new System.Drawing.Size(77, 18);
            this.SearchResultTelephoneabel1.TabIndex = 21;
            this.SearchResultTelephoneabel1.Text = "Telephone";
            // 
            // SearchResultEmailIdAnsLabel1
            // 
            this.SearchResultEmailIdAnsLabel1.AutoEllipsis = true;
            this.SearchResultEmailIdAnsLabel1.BackColor = System.Drawing.Color.White;
            this.SearchResultEmailIdAnsLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchResultEmailIdAnsLabel1.Location = new System.Drawing.Point(207, 119);
            this.SearchResultEmailIdAnsLabel1.Name = "SearchResultEmailIdAnsLabel1";
            this.SearchResultEmailIdAnsLabel1.Size = new System.Drawing.Size(219, 29);
            this.SearchResultEmailIdAnsLabel1.TabIndex = 20;
            // 
            // SearchResultLabel1
            // 
            this.SearchResultLabel1.AutoSize = true;
            this.SearchResultLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchResultLabel1.Location = new System.Drawing.Point(89, 121);
            this.SearchResultLabel1.Name = "SearchResultLabel1";
            this.SearchResultLabel1.Size = new System.Drawing.Size(60, 18);
            this.SearchResultLabel1.TabIndex = 19;
            this.SearchResultLabel1.Text = "Email Id";
            // 
            // SearchEmailIdRadioButton1
            // 
            this.SearchEmailIdRadioButton1.AutoSize = true;
            this.SearchEmailIdRadioButton1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchEmailIdRadioButton1.Location = new System.Drawing.Point(327, 21);
            this.SearchEmailIdRadioButton1.Name = "SearchEmailIdRadioButton1";
            this.SearchEmailIdRadioButton1.Size = new System.Drawing.Size(115, 23);
            this.SearchEmailIdRadioButton1.TabIndex = 18;
            this.SearchEmailIdRadioButton1.TabStop = true;
            this.SearchEmailIdRadioButton1.Text = "By Email ID";
            this.SearchEmailIdRadioButton1.UseVisualStyleBackColor = true;
            // 
            // SearchTransNumRadioButton1
            // 
            this.SearchTransNumRadioButton1.AutoSize = true;
            this.SearchTransNumRadioButton1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchTransNumRadioButton1.Location = new System.Drawing.Point(92, 21);
            this.SearchTransNumRadioButton1.Name = "SearchTransNumRadioButton1";
            this.SearchTransNumRadioButton1.Size = new System.Drawing.Size(208, 23);
            this.SearchTransNumRadioButton1.TabIndex = 13;
            this.SearchTransNumRadioButton1.TabStop = true;
            this.SearchTransNumRadioButton1.Text = "By Transaction Number";
            this.SearchTransNumRadioButton1.UseVisualStyleBackColor = true;
            // 
            // SearchTransactionsListBox1
            // 
            this.SearchTransactionsListBox1.FormattingEnabled = true;
            this.SearchTransactionsListBox1.ItemHeight = 18;
            this.SearchTransactionsListBox1.Location = new System.Drawing.Point(828, 23);
            this.SearchTransactionsListBox1.Name = "SearchTransactionsListBox1";
            this.SearchTransactionsListBox1.Size = new System.Drawing.Size(268, 76);
            this.SearchTransactionsListBox1.TabIndex = 16;
            this.InvestMeToolTip1.SetToolTip(this.SearchTransactionsListBox1, "Click on each transaction to see the details");
            this.SearchTransactionsListBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TransactionsListBox1_MouseClick);
            // 
            // InvestmentAmountGroupBox1
            // 
            this.InvestmentAmountGroupBox1.Controls.Add(this.InvestmentAmountLabel1);
            this.InvestmentAmountGroupBox1.Controls.Add(this.InvestmentAmountTextBox1);
            this.InvestmentAmountGroupBox1.Controls.Add(this.DisplayButton1);
            this.InvestmentAmountGroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestmentAmountGroupBox1.Location = new System.Drawing.Point(303, 250);
            this.InvestmentAmountGroupBox1.Name = "InvestmentAmountGroupBox1";
            this.InvestmentAmountGroupBox1.Size = new System.Drawing.Size(994, 112);
            this.InvestmentAmountGroupBox1.TabIndex = 1;
            this.InvestmentAmountGroupBox1.TabStop = false;
            this.InvestmentAmountGroupBox1.Text = "Please enter investment amount";
            this.InvestMeToolTip1.SetToolTip(this.InvestmentAmountGroupBox1, "Enter the amount to be invested");
            // 
            // SearchListTransNumsLabel1
            // 
            this.SearchListTransNumsLabel1.AutoSize = true;
            this.SearchListTransNumsLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchListTransNumsLabel1.Location = new System.Drawing.Point(577, 23);
            this.SearchListTransNumsLabel1.Name = "SearchListTransNumsLabel1";
            this.SearchListTransNumsLabel1.Size = new System.Drawing.Size(219, 18);
            this.SearchListTransNumsLabel1.TabIndex = 31;
            this.SearchListTransNumsLabel1.Text = "Transaction Numbers by Email :";
            // 
            // InvestMeToolTip1
            // 
            this.InvestMeToolTip1.ShowAlways = true;
            this.InvestMeToolTip1.ToolTipTitle = "InvestMeToolTip";
            // 
            // InvestMeForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Brown;
            this.ClientSize = new System.Drawing.Size(1854, 1044);
            this.Controls.Add(this.InvestmentAmountGroupBox1);
            this.Controls.Add(this.SearchGroupBox1);
            this.Controls.Add(this.SummaryGroupBox1);
            this.Controls.Add(this.EnterClientDetailsGroupBox1);
            this.Controls.Add(this.PlanGroupBox1);
            this.Controls.Add(this.InvestMeLabel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ExitButton1);
            this.Controls.Add(this.ClearButton1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InvestMeForm1";
            this.Text = "MyMoney Bank Corp";
            this.Load += new System.EventHandler(this.InvestMeForm1_Load);
            this.PlanGroupBox1.ResumeLayout(false);
            this.PlanGroupBox1.PerformLayout();
            this.EnterClientDetailsGroupBox1.ResumeLayout(false);
            this.EnterClientDetailsGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.SummaryGroupBox1.ResumeLayout(false);
            this.SummaryGroupBox1.PerformLayout();
            this.SearchGroupBox1.ResumeLayout(false);
            this.SearchGroupBox1.PerformLayout();
            this.InvestmentAmountGroupBox1.ResumeLayout(false);
            this.InvestmentAmountGroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button DisplayButton1;
        private System.Windows.Forms.Button ProceedButton1;
        private System.Windows.Forms.Button ClearButton1;
        private System.Windows.Forms.Button ExitButton1;
        private System.Windows.Forms.Button SummaryButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label InvestmentAmountLabel1;
        private System.Windows.Forms.TextBox InvestmentAmountTextBox1;
        private System.Windows.Forms.Label InvestMeLabel1;
        private System.Windows.Forms.GroupBox PlanGroupBox1;
        private System.Windows.Forms.Button ConfirmButton1;
        private System.Windows.Forms.RadioButton TenYearsPlanRadioButton1;
        private System.Windows.Forms.RadioButton FiveYearsPlanRadioButton1;
        private System.Windows.Forms.RadioButton ThreeYearsPlanRadioButton1;
        private System.Windows.Forms.RadioButton OneYearPlanRadioButton1;
        private System.Windows.Forms.GroupBox EnterClientDetailsGroupBox1;
        private System.Windows.Forms.Label TransactionNumberAnswerClientDetailsLabel1;
        private System.Windows.Forms.Label TransactionNumberClientDetailsLabel1;
        private System.Windows.Forms.TextBox EmailIDAnsTextBox1;
        private System.Windows.Forms.TextBox TelephoneAnsTextBox1;
        private System.Windows.Forms.TextBox ClientNameAnsTextBox1;
        private System.Windows.Forms.Label TelephoneLabel1;
        private System.Windows.Forms.Label EmailIDLabel1;
        private System.Windows.Forms.Label ClientNameLabel1;
        private System.Windows.Forms.GroupBox SummaryGroupBox1;
        private System.Windows.Forms.Label TotalAmountInvestedLabel1;
        private System.Windows.Forms.ListBox SummaryTransactionNumberListBox1;
        private System.Windows.Forms.Label TotalInterestAnsLabel1;
        private System.Windows.Forms.Label TotalInterestLabel1;
        private System.Windows.Forms.Label TotalAmountInvestedAnsLabel1;
        private System.Windows.Forms.Label AverageDurationAnsLabel1;
        private System.Windows.Forms.Label AverageDurationLabel1;
        private System.Windows.Forms.Button SearchButton1;
        private System.Windows.Forms.TextBox SearchTextBox1;
        private System.Windows.Forms.GroupBox SearchGroupBox1;
        private System.Windows.Forms.ListBox SearchTransactionsListBox1;
        private System.Windows.Forms.RadioButton SearchEmailIdRadioButton1;
        private System.Windows.Forms.RadioButton SearchTransNumRadioButton1;
        private System.Windows.Forms.Label SearchResultTermPlanAnswerLabel1;
        private System.Windows.Forms.Label SearchResultTermPlanLabel1;
        private System.Windows.Forms.Label SearchResultBalanceAmountAnswerLabel1;
        private System.Windows.Forms.Label SearchResultBalanceAmountLabel1;
        private System.Windows.Forms.Label SearchResultInvestedAmountAnswerLabel1;
        private System.Windows.Forms.Label SearchResultInvestedAmountLabel1;
        private System.Windows.Forms.Label SearchResultClientNameAnswerLabel1;
        private System.Windows.Forms.Label SearchResultNameLabel1;
        private System.Windows.Forms.Label SearchResultTelephoneAnswerLabel1;
        private System.Windows.Forms.Label SearchResultTelephoneabel1;
        private System.Windows.Forms.Label SearchResultEmailIdAnsLabel1;
        private System.Windows.Forms.Label SearchResultLabel1;
        private System.Windows.Forms.GroupBox InvestmentAmountGroupBox1;
        private System.Windows.Forms.Label SummaryListTranNumLabel1;
        private System.Windows.Forms.Label SearchListTransNumsLabel1;
        private System.Windows.Forms.ToolTip InvestMeToolTip1;
    }
}

